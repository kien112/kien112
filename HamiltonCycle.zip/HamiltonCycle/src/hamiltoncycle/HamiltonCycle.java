/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hamiltoncycle;

/**
 *
 * @author 84877
 */
public class HamiltonCycle {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        String filename;
        filename = "matrix.txt";
        Graph g = new Graph();
        g.setData(filename);
        g.displayData();
        g.hamiltonCycle(0);
        System.out.println();
    }
    
}
