/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hamiltoncycle;


import java.io.*;
import java.util.*;
/**
 *
 * @author 84877
 */
public class Graph {
    int[][] a;
    int n;
    char[] v;
    
    Graph(){
        String s1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        v = s1.toCharArray();
    }
    
    void setData(String filename) throws Exception{
        int i, j;
        String s="", s1="";
        StringTokenizer t;
        RandomAccessFile f;
        f= new RandomAccessFile(filename, "r");
        s=f.readLine();
        n= Integer.parseInt(s.trim());
        a= new int[n][n];
        for (i = 0; i < n; i++) {
            s=f.readLine();
            t=new StringTokenizer(s);
            for (j = 0; j < n; j++) {
                s1= t.nextToken();
                a[i][j]= Integer.parseInt(s1.trim());
                
            }
        }
        f.close();
    }
    
    void displayData(){
        int i, j;
        System.out.println("\n The adjacency matrix of the graph:");
        System.out.println("======================================");
        for (i = 0; i < n; i++) {
            System.out.println("\n");
            for ( j = 0; j < n; j++) {
                System.out.printf("%3d", a[i][j]);
            }
        }
        System.out.println();
    }
    
    void displayCycle(HamilCycle c){
        for (int i = 0; i <= c.m; i++) {
            System.out.print(" "+ (c.cyc[i]+1));
        }
        System.out.println("\n");
    }
    
    boolean isUndirected(){
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if(a[i][j]!=a[j][i]){
                    return false;
                }
            }
        }
        return true;
    }
    
    boolean isConnected(){
        int h;
        boolean[] visited = new boolean[20];
        boolean[] pushed = new boolean[20];
        for (int i = 0; i < n; i++) {
            visited[i] = false;
            pushed[i] = false;
        }
        MyStack t = new MyStack();
        t.push(new Integer(0));
        pushed[0]=true;
        System.out.println();
        while(!t.isEmpty()){
            h = ((Integer)t.pop()).intValue();
            visited[h] = true;
            for (int i = n-1; i >= 0; i--) {
                if(a[h][i]>0 && !pushed[i]){
                    t.push(i);
                    pushed[i]=true;
                }
            }
        }
        for (int i = 0; i < n; i++) {
            if(!visited[i]){
                return false;
            }
        }
        return true;
    }
    
    void hamiltonCycle(HamilCycle c, boolean visited[], int i){
        int j;
        for (j = 0; j < n; j++) {
            if(a[c.cyc[i-1]][j] >0 && !visited[j]){
                c.cyc[i] = j;
                c.m++;
                visited[j] = true;
                if(i<n){
                    if(c.cyc[i] != c.cyc[0]){
                        hamiltonCycle(c, visited, i+1);
                    }
                }else if(c.cyc[i] == c.cyc[0]){
                    displayCycle(c);
                }
                visited[j]=false;
                c.m--;
            }
        }
    }
    
    
    void hamiltonCycle(int k){
        if(!isUndirected() || !isConnected()){
            System.out.println("the conditions are not satisfied");
            return;
        }
        HamilCycle c = new HamilCycle();
        boolean[] visited = new boolean[20];
        c.cyc[0] = k;
        for (int i = 0; i < n; i++) {
            visited[i] = false;
        }
        
        c.cyc[0] = k;
        System.out.println("\n Hamilton cycles of the above graph");
        hamiltonCycle(c, visited, 1);
    }
}
